docker run --rm -p 8080:8000 --name paddler-container --env-file .env paddler-app
